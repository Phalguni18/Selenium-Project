	package com.MDM.Makemytrip;

	import java.io.File;
	import java.io.FileInputStream;
	import java.io.FileNotFoundException;
	import java.io.FileOutputStream;
	import java.io.IOException;
	import java.text.SimpleDateFormat;
	import java.util.Date;
	import java.util.List;
	import java.util.concurrent.TimeUnit;

	import org.apache.commons.io.FileUtils;
	import org.apache.poi.ss.usermodel.Cell;
	import org.apache.poi.ss.usermodel.Row;
	import org.apache.poi.ss.usermodel.Workbook;
	import org.apache.poi.xssf.usermodel.XSSFSheet;
	import org.apache.poi.xssf.usermodel.XSSFWorkbook;
	import org.openqa.selenium.By;
	import org.openqa.selenium.JavascriptExecutor;
	import org.openqa.selenium.OutputType;
	import org.openqa.selenium.TakesScreenshot;
	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.WebElement;
	import org.openqa.selenium.chrome.ChromeDriver;
	import org.testng.ITestResult;
	import org.testng.annotations.AfterMethod;
	import org.testng.annotations.BeforeSuite;
	import org.testng.annotations.BeforeTest;
	import org.testng.annotations.Test;
	import com.relevantcodes.extentreports.ExtentReports;
	import com.relevantcodes.extentreports.ExtentTest;
	import com.relevantcodes.extentreports.LogStatus;
	
	
	public class BookTickets 
	{
		
		public static ExtentTest extenttest ;
		public static ExtentReports extent;
		
//Extent Reports  *********************************	
		
		@BeforeTest
		public void startReport()
		{
			 ExtentReports extent = new ExtentReports (System.getProperty("user.dir") +"/test-output/STMExtentReport.html", true);
			 extent.loadConfig(new File(System.getProperty("user.dir")+"\\extent-config.xml"));
		}
		
		
		@BeforeSuite
	    public void setUp()
	    {
			extent= new ExtentReports("C:\\Users\\PhalguniRaghava\\workspace\\Makemytrip\\Report0.html");
	        extent.loadConfig(new File("C:\\Users\\PhalguniRaghava\\workspace\\Makemytrip\\extent-config.xml"));
	    }
		
// Failed Testcase Screenshot method in Extent Report ************************	
		 
	    @AfterMethod
	    
	    public void getResult(ITestResult result) throws IOException
	    {
		      if(result.getStatus() == ITestResult.FAILURE)
	        {
	        	extenttest.log(LogStatus.FAIL, " Test case FAILED due to below issues:"+result.getName());
	          	extenttest.log(LogStatus.FAIL, result.getThrowable());
	        
	            String screenshotPath = BookTickets.getScreenshot(driver, result.getName());
	      	    extenttest.log(LogStatus.FAIL,   extenttest.addScreenCapture(screenshotPath));
	        }
	        else if(result.getStatus() == ITestResult.SUCCESS)
	        {
	        
	        	extenttest.log(LogStatus.PASS," Test Case PASSED"+ result.getName());
	        }
	        else if(result.getStatus() == ITestResult.SKIP)
	        {
	        	extenttest.log(LogStatus.SKIP," Test Case SKIPPED" + result.getName());
	        	extenttest.log(LogStatus.SKIP, result.getThrowable());
	        }
	        extent.flush();
	        
	    }
	    
	//Extent Report Screenshot method    
	    public static String getScreenshot(WebDriver driver, String screenshotName) throws IOException
		{
			String dateName = new SimpleDateFormat("yyyyMMddhhmmss").format(new Date());
			TakesScreenshot ts = (TakesScreenshot) driver;
			File source = ts.getScreenshotAs(OutputType.FILE);
		
			String destination = System.getProperty("user.dir") + "/FailedTestsScreenshots/" + screenshotName + dateName
				+ ".png";
			File finalDestination = new File(destination);
			FileUtils.copyFile(source, finalDestination);
			return destination;
		}
		
		

		WebDriver driver;
	    @Test
	    public void trip() throws InterruptedException, IOException
	    {
	    	extenttest = extent.startTest("trip");
	        System.setProperty("webdriver.chrome.driver","C:\\chromedriver_win32\\chromedriver.exe");
	        driver = new ChromeDriver();
	      // Launch the application	makemytrip	
	        driver.get("https://www.makemytrip.com/");
	        driver.manage().window().maximize();
	        Thread.sleep(10);
	        String actualTitle=" ";
	        actualTitle=driver.getTitle();
	        String url=driver.getCurrentUrl();
	        System.out.println(url);
	        String expectedTitle=actualTitle;
	        if(actualTitle.contentEquals(expectedTitle))
	        {
	            System.out.println("Test pass: Url opened");
	        }
	        else
	        {
	            System.out.println("Test fail: Wrong Url");
	        }

	        System.out.println("Selecting one way travel");
	        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	        Thread.sleep(7000);
	   //Select From , To and Date and sendkeys.  
	        driver.findElement(By.xpath("//li[@class='makeFlex hrtlCenter font10 makeRelative lhUser']")).click();
	        driver.findElement(By.xpath("//div//a//i[@class='wewidgeticon we_close']")).click();
	        Thread.sleep(2000);
	        //Selecting From place
	        driver.findElement(By.xpath(" //div[contains(@class,'fsw_inputBox searchCity inactiveWidget')]//label")).click();
	        Thread.sleep(2000);
	      
	        driver.findElement(By.xpath("//input[@placeholder='From']")).click();
	        Thread.sleep(2000);
	     
	        driver.findElement(By.xpath("//input[@placeholder='From']")).sendKeys("Hyderabad");
	        Thread.sleep(2000);
	        driver.findElement(By.xpath("//i[@class='wewidgeticon we_close']")).click();
	        Thread.sleep(2000);
	        driver.findElement(By.xpath("//li[@id='react-autowhatever-1-section-0-item-0']//div[contains(@class,'calc60')]")).click();
	        Thread.sleep(2000);
	        
	        //Selecting To place
	        
	        driver.findElement(By.xpath("//input[@placeholder='To']")).click();
	        driver.findElement(By.xpath("//input[contains(@placeholder,'To')]")).sendKeys("Mumbai");
	        Thread.sleep(2000);
	        driver.findElement(By.xpath("//p[contains(text(),'Mumbai, India')]")).click();
	        Thread.sleep(2000);
	        
	        driver.findElement(By.xpath("//span[contains(text(),'DEPARTURE')]")).click();
	        driver.findElement(By.xpath("//span[@class='DayPicker-NavButton DayPicker-NavButton--next']")).click();
	        Thread.sleep(2000);
	        
	   //Selecting Dte August 25th,2020 	    
	        driver.findElement(By.xpath("//div[contains(@class,'DayPicker-Months')]//div[2]//div[3]//div[5]//div[3]//div[1]//p[1]")).click();
	        Thread.sleep(2000);
	   //Click on Search button 
	        driver.findElement(By.xpath("//a[contains(@class,'primaryBtn font24 latoBold widgetSearchBtn')]")).click();
	        
	  // a.	To find the total number of flights showing in search results      
	        
	     //   List<WebElement> flights = driver.findElements(By.xpath("//body/div[@id='root']/div/div[@id='root-element']/div[@id='body--wraper']/div[@id='section--wrapper']/div[@id='left-side--wrapper']/div[@class='fli-intl-lhs pull-left']/div[1]"));
	        
	        List<WebElement> flights = driver.findElements(By.xpath("//div[@class='fli-list-body-section']"));
	        
	        Thread.sleep(15000);
	        System.out.println("total no of flights: "+flights.size());
	        for (WebElement product : flights)
	        {
	            System.out.println(product.getText());
	        }
	    
	    
	    
	 /*  b.	To import the below search results in excel file
	       	Flight No, Flight Name, Flight Time, Departure time, Arrival time, Price.*/
	        
	        List<WebElement> flights1 = driver.findElements(By.xpath("//div[@class='fli-list-body-section']"));
	        
	        try 
	        {
	            
	        	  FileInputStream file = new FileInputStream(new File("C:\\Users\\PhalguniRaghava\\workspace\\Makemytrip\\Flightdetails.xlsx")); 
	        	  XSSFWorkbook workbook = new XSSFWorkbook(file);
	        	  XSSFSheet sheet = workbook.getSheetAt(0); 
	        	  for (int i=1; i <= sheet.getLastRowNum(); i++)
	        	  {
	        		  	XSSFWorkbook wb = new XSSFWorkbook(file);
	        		   	XSSFSheet sh = wb.createSheet();
	        		   	sh.createRow(0).createCell(0).setCellValue("Flight No");
	        		   	sh.createRow(0).createCell(1).setCellValue("Flight Name");
	       	        	sh.createRow(0).createCell(2).setCellValue("Flight Time");
	       	        	sh.createRow(0).createCell(3).setCellValue("Departure time");
	       	        	sh.createRow(0).createCell(4).setCellValue("Arrival time");
	       	        	sh.createRow(0).createCell(5).setCellValue("Price");
	        	        Cell resultCell= sheet.getRow(i).getCell(3);
	        	 
	        	        String keyword = sheet.getRow(i).getCell(2).getStringCellValue();      
	        	  
	        	        driver.manage().timeouts().implicitlyWait(10000, TimeUnit.MILLISECONDS);
	        	 
	        	        String searchText =  ((WebElement) flights1).getAttribute("value");
	        	 
	        	        if(searchText.equals(keyword))
	        	        {
	        	                System.out.println("Search is successful.");
	        	                resultCell.setCellValue("PASS");
	        	        } else 
	        	        {
	        	                System.out.println("Search is not successful.");
	        	                resultCell.setCellValue("FAIL");
	        	        }
	        	  }
	       
	        	  workbook.close();
	        	  file.close();
	        	 
	        	  FileOutputStream outFile =new FileOutputStream(new File("C:\\testdata-result.xlsx"));
	        	  workbook.write(outFile);
	        	  outFile.close();
	        } 
	        catch (FileNotFoundException fnfe) 
	        {
	    	  fnfe.printStackTrace();
	    	 } 
	        catch (IOException ioe) 
	        {
	    	  ioe.printStackTrace();
	    	 }
	    	 }
	        	  
	        }
	  
	
	
	   	    

	
	
